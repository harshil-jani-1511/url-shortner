

<?php $__env->startSection('title', 'Clients'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
   <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">
        Back to Dashboard
    </a>

    <a href="<?php echo e(route('super-admin.clients.create')); ?>" class="btn btn-primary">
        Invite
    </a>
</div>

<div class="card">
    <h2>All Clients</h2>

    <?php if($clients->isEmpty()): ?>
        <p>No clients found.</p>
    <?php else: ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Client Name</th>
                        <th>Total Users</th>
                        <th>Total Generated URLs</th>
                        <th>Total URL Hits</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($client->name); ?></td>
                            <td><?php echo e($client->users_count); ?></td>
                            <td><?php echo e($client->urls_count); ?></td>
                            <td><?php echo e($client->url_clicks_count); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="pagination-wrapper">
            <?php echo e($clients->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\url-shortner\resources\views/super-admin/clients/index.blade.php ENDPATH**/ ?>