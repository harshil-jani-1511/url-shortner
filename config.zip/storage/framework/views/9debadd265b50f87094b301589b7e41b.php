


<?php $__env->startSection('title', 'Invite Team Member'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1>Invite Team Member</h1>
        <p>Invite a new member to your company.</p>
    </div>
    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">
        Back to Dashboard
    </a>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul style="margin: 0; padding-left: 20px;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="card">
    <h2>Invite Team Member</h2>

    <form method="POST" action="<?php echo e(route('team.invitations.store')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="name">User Name</label>
            <input
                type="text"
                id="name"
                name="name"
                value="<?php echo e(old('name')); ?>"
                placeholder="Enter user's full name"
                required
            >
        </div>

        <div class="form-group">
            <label for="email">Email Address</label>
            <input
                type="email"
                id="email"
                name="email"
                value="<?php echo e(old('email')); ?>"
                placeholder="Enter email address"
                required
            >
        </div>

        <div class="form-group">
            <label for="role">Role</label>
            <select id="role" name="role" required>
                <option value="">Select role</option>
                <option value="admin" <?php echo e(old('role') === 'admin' ? 'selected' : ''); ?>>
                    Admin
                </option>
                <option value="member" <?php echo e(old('role') === 'member' ? 'selected' : ''); ?>>
                    Member
                </option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">
            Send Invitation
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\url-shortner\resources\views/team/invite.blade.php ENDPATH**/ ?>