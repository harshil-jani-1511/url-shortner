<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<?php
    $isSuperAdmin = auth()->user()->isSuperAdmin();
    $isAdmin = auth()->user()->isAdmin();
    $isMember = auth()->user()->isMember();
?>

<div class="page-header">
    <div>
        <h1>Dashboard</h1>
        <p>Welcome, <?php echo e(auth()->user()->name); ?>.</p>
    </div>
</div>


<?php if($isSuperAdmin): ?>

    
    <div class="card">
        <div class="section-header">
            <h2>Clients</h2>

            <a href="<?php echo e(route('super-admin.clients.create')); ?>" class="btn btn-primary">
                Invite
            </a>
        </div>

        <?php if($clients->isEmpty()): ?>
            <p class="empty-message">No clients found.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Client Name</th>
                            <th>Total Users</th>
                            <th>Total Generated URLs</th>
                            <th>Total URL Hits</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $clients->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($client->name); ?></td>
                                <td><?php echo e($client->users_count); ?></td>
                                <td><?php echo e($client->urls_count); ?></td>
                                <td><?php echo e($client->url_clicks_count); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php if($clients->count() > 2): ?>
                <div class="section-footer">
                    <a href="<?php echo e(route('super-admin.clients.index')); ?>">View All Clients</a>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    
    <div class="card">
        <div class="section-header">
            <h2>Generated Short URLs</h2>
            <?php echo $__env->make('dashboard.partials.url-filters', [
                'downloadRoute' => route('super-admin.urls.export')
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>


        <?php echo $__env->make('dashboard.partials.url-list', [
            'urls' => $recentUrls->take(2),
            'showCompany' => true
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if($recentUrls->count() > 2): ?>
            <div class="section-footer">
                <a href="<?php echo e(route('super-admin.urls.index', request()->query())); ?>">
                    View All URLs
                </a>
            </div>
        <?php endif; ?>
    </div>

<?php endif; ?>


<?php if($isAdmin): ?>

    
    <div class="card">
        
        <div class="section-header">
            <div class="header-content-admin">
                <h2>Generated Short URLs</h2>
                <a href="<?php echo e(route('app.urls.index')); ?>" class="btn btn-primary">
                    Generate
                </a>
            </div>
            <?php echo $__env->make('dashboard.partials.url-filters', [
                'downloadRoute' => route('app.urls.export')
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <?php echo $__env->make('dashboard.partials.url-list', [
            'urls' => $recentUrls,
            'showCompany' => false
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="section-footer">
            <a href="<?php echo e(route('app.urls.all')); ?>">View All URLs</a>
        </div>
    </div>

    
    <div class="card">
        <div class="section-header">
            <h2>Team Members</h2>
            <a href="<?php echo e(route('team.invite')); ?>" class="btn btn-primary">
                Invite
            </a>
        </div>

        <?php if($teamMembers->isEmpty()): ?>
            <p class="empty-message">No team members found.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Joined At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($member->name); ?></td>
                                <td><?php echo e($member->email); ?></td>
                                <td><?php echo e(ucfirst($member->role)); ?></td>
                                <td><?php echo e($member->created_at->format('d M Y')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

        <div class="section-footer">
            <a href="<?php echo e(route('team.members.index')); ?>">View All</a>
        </div>
    </div>

<?php endif; ?>


<?php if($isMember): ?>

    <div class="card">
        <div class="section-header">
            <div class="header-content-admin">
                <h2>Generated Short URLs</h2>
                <a href="<?php echo e(route('app.urls.index')); ?>" class="btn btn-primary">
                    Generate
                </a>
            </div>
            <?php echo $__env->make('dashboard.partials.url-filters', [
                'downloadRoute' => route('app.urls.export')
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <?php echo $__env->make('dashboard.partials.url-list', [
            'urls' => $memberUrls,
            'showCompany' => false
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="pagination pt-3">
            <?php echo e($memberUrls->links()); ?>

        </div>
    </div>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\url-shortner\resources\views/dashboard.blade.php ENDPATH**/ ?>