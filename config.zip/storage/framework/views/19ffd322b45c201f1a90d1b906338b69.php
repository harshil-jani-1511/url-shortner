

<?php $__env->startSection('title', 'Generate URL'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1>Generate Short URL</h1>
    </div>
    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">
        Back to Dashboard
    </a>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul style="margin: 0; padding-left: 20px;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="card">
    <form method="POST" action="<?php echo e(route('app.urls.store')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="original_url">Long URL</label>
            <input
                type="url"
                id="original_url"
                name="original_url"
                value="<?php echo e(old('original_url')); ?>"
                placeholder="https://example.com"
                required
            >
        </div>

        <button type="submit" class="btn btn-primary">
            Generate
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\url-shortner\resources\views/app/urls/index.blade.php ENDPATH**/ ?>