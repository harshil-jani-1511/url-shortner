<?php if($urls->isEmpty()): ?>
    <p class="empty-message">No URLs found for this period.</p>
<?php else: ?>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <?php if($showCompany): ?>
                        <th>Short URL</th>
                        <th>Long URL</th>
                        <th>Hits</th>
                        <th>Company Name</th>
                        <th>Created On</th>
                    <?php else: ?>
                        <th>Created By</th>
                        <th>Original URL</th>
                        <th>Short URL</th>
                        <th>Clicks</th>
                        <th>Created At</th>
                    <?php endif; ?>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if($showCompany): ?>
                            <td>
                                <a href="<?php echo e(route('short-urls.redirect', ['shortCode' => $url->short_code])); ?>"
                                   target="_blank">
                                    <?php echo e(url('/s/' . $url->short_code)); ?>

                                </a>
                            </td>

                            <td style="max-width: 220px; overflow-wrap: anywhere;">
                                <?php echo e($url->original_url); ?>

                            </td>

                            <td><?php echo e($url->clicks_count); ?></td>
                            <td><?php echo e($url->company?->name ?? 'N/A'); ?></td>
                            <td><?php echo e($url->created_at?->format('d M Y')); ?></td>
                        <?php else: ?>
                            <td><?php echo e($url->user?->name ?? 'N/A'); ?></td>

                            <td style="max-width: 220px; overflow-wrap: anywhere;">
                                <?php echo e($url->original_url); ?>

                            </td>

                            <td>
                                <a href="<?php echo e(route('short-urls.redirect', ['shortCode' => $url->short_code])); ?>"
                                   target="_blank">
                                    <?php echo e(route('short-urls.redirect', ['shortCode' => $url->short_code])); ?>

                                </a>
                            </td>

                            <td><?php echo e($url->clicks_count); ?></td>
                            <td><?php echo e($url->created_at?->format('d M Y')); ?></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\url-shortner\resources\views/dashboard/partials/url-list.blade.php ENDPATH**/ ?>