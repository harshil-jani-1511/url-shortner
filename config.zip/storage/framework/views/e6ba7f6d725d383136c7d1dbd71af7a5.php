


<?php $__env->startSection('title', 'All URLs'); ?>
<?php $__env->startSection('page-heading', 'Clients'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-header">
    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">
        Back to Dashboard
    </a>
</div>

<div class="card">
    <div class="card-header">
        <h2>Generated Short URLs</h2>
    
        <?php if($urls->isEmpty()): ?>
            <p>No URLs found.</p>
        <?php else: ?>
        <div>
            <form method="GET" action="<?php echo e(route('super-admin.urls.index')); ?>" class="filter-form">
                <div class="form-group">
                    <!-- <label for="date_filter">Date Filter</label> -->
                    <select name="date_filter" id="date_filter" onchange="this.form.submit()">
                        <option value="all" <?php echo e($dateFilter === 'all' ? 'selected' : ''); ?>>All Time</option>
                        <option value="today" <?php echo e($dateFilter === 'today' ? 'selected' : ''); ?>>Today</option>
                        <option value="last_week" <?php echo e($dateFilter === 'last_week' ? 'selected' : ''); ?>>Last Week</option>
                        <option value="last_month" <?php echo e($dateFilter === 'last_month' ? 'selected' : ''); ?>>Last Month</option>
                        <option value="this_month" <?php echo e($dateFilter === 'this_month' ? 'selected' : ''); ?>>This Month</option>
                        <option value="custom" <?php echo e($dateFilter === 'custom' ? 'selected' : ''); ?>>Custom</option>
                    </select>
                </div>

                <?php if($dateFilter === 'custom'): ?>
                    <div class="form-group">
                        <label>From</label>
                        <input type="date" name="from_date" value="<?php echo e(request('from_date')); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>To</label>
                        <input type="date" name="to_date" value="<?php echo e(request('to_date')); ?>" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Apply</button>
                <?php endif; ?>
            </form>
            <a href="<?php echo e(route('super-admin.urls.export', request()->query())); ?>" class="btn btn-primary">
                Download
            </a>
        </div>
    </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Original URL</th>
                        <th>Short URL</th>
                        <th>Company</th>
                        <th>Created By</th>
                        <th>Clicks</th>
                        <th>Created</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="max-width: 250px; overflow-wrap: anywhere;">
                                <?php echo e($url->original_url); ?>

                            </td>

                            <td>
                                <a
                                    href="<?php echo e(route('short-urls.redirect', ['shortCode' => $url->short_code])); ?>"
                                    target="_blank"
                                >
                                    <?php echo e(url('/s/' . $url->short_code)); ?>

                                </a>
                            </td>

                            <td><?php echo e($url->company?->name ?? 'N/A'); ?></td>

                            <td><?php echo e($url->user?->name ?? 'N/A'); ?></td>

                            <td><?php echo e($url->clicks_count); ?></td>

                            <td><?php echo e($url->created_at?->format('d M Y')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="pagination pt-3">
            <?php echo e($urls->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\url-shortner\resources\views/super-admin/urls/index.blade.php ENDPATH**/ ?>