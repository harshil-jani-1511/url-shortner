

<?php $__env->startSection('title', 'Team Members'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">
        Back to Dashboard
    </a>
</div>

<div class="card">
    <h2>Team Members</h2>

    <?php if($members->isEmpty()): ?>
        <p class="empty-message">No team members found.</p>
    <?php else: ?>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Joined At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($member->name); ?></td>
                            <td><?php echo e($member->email); ?></td>
                            <td><?php echo e(ucfirst($member->role)); ?></td>
                            <td><?php echo e($member->created_at->format('d M Y')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="pagination pt-3">
            <?php echo e($members->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\url-shortner\resources\views/team/index.blade.php ENDPATH**/ ?>