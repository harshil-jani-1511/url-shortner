 

<?php $__env->startSection('title', 'All Generated URLs'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">

    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">
        Back to Dashboard
    </a>
</div>

<div class="card">
    <div class="section-header">
        <h1>Generated Short URLs</h1>
        
        <?php echo $__env->make('dashboard.partials.url-filters', [
            'downloadRoute' => route('app.urls.export')
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>


    
    <?php echo $__env->make('dashboard.partials.url-list', [
        'urls' => $urls,
        'showCompany' => false
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div class="pagination pt-3">
        <?php echo e($urls->links()); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\url-shortner\resources\views/app/urls/all.blade.php ENDPATH**/ ?>